// This file should import both data files and export them as shown in the lecture code
import * as events from "./events.js";
import * as attendees from "./attendees.js";

export { events, attendees };
